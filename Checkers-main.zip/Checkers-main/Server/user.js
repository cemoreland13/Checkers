
module.exports = class User{
    constructor(name,id){
        this.name = name;
        this.id = id
        this.color = null;
    }
}

